#!/bin/bash
echo "192.168.10.10	control" >> /etc/hosts
echo "192.168.10.20	vagrant1" >> /etc/hosts
